import butelka1 from "./productImages/butelka1.jpg";

const images = [butelka1];

export default images;
