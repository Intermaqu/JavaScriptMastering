var PlatformMovement = pc.createScript('platformMovement');

// initialize code called once per entity
PlatformMovement.prototype.initialize = function () {
    this.speed = -6;
    this.gameStart = false;

    this.parent = this.entity.parent;
    this.childCount = this.parent.children.length;

    this.app.on("PlatformMovement:StartGame", function (canStart) {
        this.gameStart = canStart;
    }, this)
};

// update code called every frame
PlatformMovement.prototype.update = function (dt) {
    if (!this.gameStart) {
        return;
    }

    let { x, y, z } = this.entity.getLocalPosition()
    let localX = x + this.speed * dt;

    this.entity.setLocalPosition(localX, y, z)

};

PlatformMovement.prototype.postUpdate = function (dt) {
    let { x, y, z } = this.entity.getLocalPosition()

    if (x <= -14) {
        localX = this.parent.children.at(-1).getLocalPosition().x + 2;
        this.entity.reparent(this.parent);
        this.entity.setLocalPosition(localX, y, z)
        this.app.fire("GameManager:CreateObstacle", this.entity)
    }
};
