var Collectable = pc.createScript('collectable');

// initialize code called once per entity
Collectable.prototype.initialize = function () {
    this.entity.collision.on("triggerenter", this.onTriggerEnter, this);
    this.isHit = false

    this.app.on("Collectable:Destroy", function () {
        this.entity.destroy();
    }, this)
};

// update code called every frame
Collectable.prototype.update = function (dt) {
    if (this.entity.getPosition().x < -12) {
        this.entity.destroy()
    }
};

Collectable.prototype.onTriggerEnter = function (env) {
    if (env.tags.has("player") && !this.isHit) {
        this.isHit = true;
        this.app.fire("GameManager:AddScore")
        this.app.fire("GameManager:Sound:collect")
        this.entity.destroy()
    }
}

// swap method called for script hot-reloading
// inherit your script state here
// Collectable.prototype.swap = function(old) { };

// to learn more about script anatomy, please read:
// https://developer.playcanvas.com/en/user-manual/scripting/