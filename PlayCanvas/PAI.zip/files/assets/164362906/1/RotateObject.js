var RotateObject = pc.createScript('rotateObject');

// initialize code called once per entity
RotateObject.prototype.initialize = function () {
    this.time = 0;
};

// update code called every frame
RotateObject.prototype.update = function (dt) {
    const { x, y, z } = this.entity.getPosition()
    this.time += dt
    this.entity.rotate(0, 1, 0)
    console.log(this.time)
    this.entity.setPosition(x, y + Math.sin(this.time * 3) / 500, z)
};

// swap method called for script hot-reloading
// inherit your script state here
// RotateObject.prototype.swap = function(old) { };

// to learn more about script anatomy, please read:
// https://developer.playcanvas.com/en/user-manual/scripting/