var GameManager = pc.createScript('gameManager');

GameManager.attributes.add("playBtn", { type: "entity" })
GameManager.attributes.add("score", { type: "entity" })
GameManager.attributes.add("title", { type: "entity" })
GameManager.attributes.add("obstacles", { type: "asset", assetType: "template", array: true })
GameManager.attributes.add("soundManager", { type: "entity" })


// initialize code called once per entity
GameManager.prototype.initialize = function () {

    this.gameStart = false;
    this.homeMenu();
    this.currentScore = 0;

    this.sound = this.soundManager.sound;

    this.playBtn.button.on("click", function () {
        this.app.fire("Player:StartGame", true)
        this.app.fire("PlatformMovement:StartGame", true)
        this.gameMenu();
    }, this)

    this.app.on("GameManager:StartGame", function () {
        this.app.fire("Player:StartGame", true)
        this.app.fire("PlatformMovement:StartGame", true)
    }, this)

    this.app.on("GameManager:GameOver", function () {
        this.app.fire("Player:Hit", false)
        this.app.fire("Player:StartGame", false)
        this.app.fire("PlatformMovement:StartGame", false)
        this.currentScore = 0;

        setTimeout(() => {
            this.homeMenu()
            this.currentScore = 0;
            this.score.element.text = `${this.currentScore}`
            this.app.fire("GameManager:Reset")
        }, 3000)

    }, this)

    this.app.on("GameManager:Reset", function () {
        this.app.fire("Obstacles:Destroy");
        this.app.fire("Collectable:Destroy");
        this.app.fire("Player:Reset")
    }, this)

    this.app.on("GameManager:AddScore", function () {
        this.currentScore += 1;
        this.score.element.text = `${this.currentScore}`
    }, this)

    this.app.on("GameManager:Sound:hit", function () {
        this.sound.play("hit")
    }, this)

    this.app.on("GameManager:Sound:land", function () {
        this.sound.play("land")
    }, this)

    this.app.on("GameManager:Sound:jump", function () {
        this.sound.play("jump")
    }, this)

    this.app.on("GameManager:Sound:collect", function () {
        this.sound.play("collect")
    }, this)

    let place = 0

    this.app.on("GameManager:CreateObstacle", function (groundParent) {
        place += 1;

        if (place < 5) {
            return;
        }

        place = 0;

        const random = Math.floor(Math.random() * (this.obstacles.length + 2))
        // TO SKIP SOME SPOTS
        if (random < this.obstacles.length) {
            const obstacle = this.obstacles[random].resource.instantiate()
            groundParent.addChild(obstacle)
            obstacle.setLocalPosition(0, 2, 0);
            obstacle.enabled = true;
        }




    }, this)
};

// update code called every frame
GameManager.prototype.update = function (dt) {

};

GameManager.prototype.homeMenu = function () {
    this.playBtn.enabled = true;
    this.score.enabled = false;
    this.title.enabled = true;
};

GameManager.prototype.gameMenu = function () {
    this.playBtn.enabled = false;
    this.score.enabled = true;
    this.title.enabled = false;
};
