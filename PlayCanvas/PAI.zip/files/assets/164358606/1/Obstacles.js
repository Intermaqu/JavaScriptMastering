var Obstacles = pc.createScript('obstacles');

// initialize code called once per entity
Obstacles.prototype.initialize = function () {
    this.entity.collision.on("triggerenter", this.onTriggerEnter, this);
    this.isHit = false

    this.app.on("Obstacles:Destroy", function () {
        this.entity.destroy();
    }, this)
};

// update code called every frame
Obstacles.prototype.update = function (dt) {
    // if (this.entity.getPosition().x < -10) {
    //     this.entity.destroy()
    // }

};

Obstacles.prototype.onTriggerEnter = function (env) {
    if (env.tags.has("player") && !this.isHit) {
        this.isHit = true;
        this.app.fire("GameManager:GameOver")
        this.app.fire("GameManager:Sound:hit")
    }
}