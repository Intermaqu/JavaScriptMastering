var ButtonAction = pc.createScript('buttonAction');

ButtonAction.attributes.add("eventName", {
    type: "string",
})
ButtonAction.prototype.initialize = function () {
    this.entity.button.on("click", function () {
        this.app.fire(this.eventName)
    }, this)
};

ButtonAction.prototype.update = function (dt) {

};
