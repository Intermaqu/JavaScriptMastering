var Player = pc.createScript('player');

Player.attributes.add("jumpPower", { type: "number", default: 500 })
Player.attributes.add("landingParticle", { type: "entity" })
Player.attributes.add("runningParticle", { type: "entity" })


// initialize code called once per entity
Player.prototype.initialize = function () {
    this.state = "idle";
    this.falling = false;
    this.entity.collision.on("collisionstart", this.onCollision, this)

    this.gameStart = false;



    this.app.on("Player:Hit", function () {
        this.entity.anim.setTrigger("hit")
    }, this)

    this.app.on("Player:Reset", function () {
        this.entity.anim.setTrigger("reset")
    }, this)

    this.app.on("Player:StartGame", function (canStart) {
        if (canStart) {
            this.state = "run"
            this.entity.anim.setTrigger("start")
        }

        this.gameStart = canStart;
    }, this)
};

// update code called every frame
Player.prototype.update = function (dt) {
    if (!this.gameStart) {
        this.runningParticle.enabled = false;
        return;
    }

    this.runningParticle.enabled = this.state == "run";

    if (this.app.keyboard.wasPressed(pc.KEY_SPACE) || this.app.keyboard.wasPressed(pc.KEY_UP)) {
        this.jump()
    }
};

Player.prototype.onCollision = function (e) {
    if (e.other.tags.has("ground")) {
        this.state = "run";
        this.app.fire("GameManager:Sound:land")
        this.falling = false;
        this.entity.anim.setBoolean("jump", false)

        this.createLandingParticle();
    }
}


Player.prototype.jump = function () {
    if (this.state != "jump") {
        this.state = "jump";
        this.falling = true;
        this.entity.anim.setBoolean("jump", true)
        this.app.fire("GameManager:Sound:jump")

        setTimeout(() => {
            this.entity.rigidbody.applyImpulse(0, this.jumpPower, 0)
        }, 200)

    }
}

Player.prototype.createLandingParticle = function () {
    const particle = this.landingParticle.clone()

    this.app.root.addChild(particle)

    particle.setPosition(0, 2, 0);
    particle.enabled = true;
}