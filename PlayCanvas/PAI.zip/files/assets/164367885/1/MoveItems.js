var MoveItems = pc.createScript('moveItems');

// initialize code called once per entity
MoveItems.attributes.add("speed", {
    type: "number",
    default: -6
})
MoveItems.attributes.add("startPos", {
    type: "number",
})
MoveItems.attributes.add("endPos", {
    type: "number",
})

MoveItems.prototype.initialize = function () {
    this.gameStart = false;
    this.app.on("PlatformMovement:StartGame", function (canStart) {
        this.gameStart = canStart;
    }, this)
};

// update code called every frame
MoveItems.prototype.update = function (dt) {
    if (!this.gameStart) return;

    const { x, y, z } = this.entity.getLocalPosition()

    let localX = x + this.speed * dt;

    if (x < this.endPos) localX = this.startPos

    this.entity.setLocalPosition(localX, y, z)
};
